﻿using System.Diagnostics;

namespace PokemonTrainer;

public class Pokemon
{
    private string name;
    private string element;
    private int health;


    public string Name { get; set; }
    public string Element { get; set; }
    public int Health { get; set; }

    public static implicit operator List<object>(Pokemon v)
    {
        throw new NotImplementedException();
    }
}
