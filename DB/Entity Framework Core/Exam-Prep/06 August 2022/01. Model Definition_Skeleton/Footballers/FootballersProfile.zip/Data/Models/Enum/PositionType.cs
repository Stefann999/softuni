﻿namespace Footballers.Data.Models.Enum
{
    public enum PositionType
    {
        Goalkeeper,
        Defender,
        Midfielder,
        Forward
    }
}
