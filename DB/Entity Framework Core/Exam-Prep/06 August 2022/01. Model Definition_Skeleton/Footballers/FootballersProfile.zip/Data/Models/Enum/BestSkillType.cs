﻿namespace Footballers.Data.Models.Enum
{
    public enum BestSkillType
    {
        Defence,
        Dribble,
        Pass,
        Shoot,
        Speed
    }
}
