﻿namespace Footballers.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=FootballersExam;Trusted_Connection=True";
    }
}
